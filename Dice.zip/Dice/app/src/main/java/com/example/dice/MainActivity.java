package com.example.dice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button btn;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.imageView);
        btn = (Button) findViewById(R.id.roll_dice);
        final Random random = new Random();
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                int randomNumber = random.nextInt( 6);

                if (randomNumber == 1){
                    imageView.setImageResource(R.drawable.dice1);
                }

                else if (randomNumber == 2){
                    imageView.setImageResource(R.drawable.dice2);
                }


                else if (randomNumber == 3){
                    imageView.setImageResource(R.drawable.dice3);
                }

                else if (randomNumber == 4){
                    imageView.setImageResource(R.drawable.dice4);
                }

                else if (randomNumber == 5){
                    imageView.setImageResource(R.drawable.dice5);
                }

                else if (randomNumber == 6){
                    imageView.setImageResource(R.drawable.dice6);
                }


            }

        });
    }
}